package com.example.cs360project;

import android.app.Activity;

public class SmsPermissionActivity extends Activity {
}
